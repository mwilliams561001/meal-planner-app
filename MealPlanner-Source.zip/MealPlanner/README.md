# Meal Planner Mobile Application

## I. Project Description

The proposed project is a mobile Meal Planner application designed to help users organize meals for the week.

- The application will give users one place to plan meals instead of keeping meal ideas in different notes, messages, or lists.
- The goal is to create a simple application that is easy to use and can be expanded as new course concepts are introduced.

## II. Problem Addressing

Meal planning can become disorganized when users have to keep track of meal ideas, schedules, and grocery needs in several different places.

- Users may spend extra time deciding what to prepare each day or forget meals they already planned.
- The Meal Planner application will address this problem by allowing users to plan meals ahead of time in one organized location.
- A weekly meal plan can also make it easier to prepare for grocery shopping and keep track of upcoming meals.

## III. Platform

The application will be developed for the Android mobile platform.

- Android was selected because the course focuses on Android mobile application development and the platform supports the features needed for this project.
- I plan to start with the basic Android development concepts we are learning and add to the app as I learn more throughout the course.

## IV. Front-End and Back-End Support

### Front End

- The front end will include the screens, buttons, text fields, and menus that the user interacts with.
- Users will be able to view their weekly meal plan, select a day, and add or edit meals.
- The interface will focus on being simple, readable, and easy to navigate.

### Back End

- The back end will support saving and retrieving the meal information entered by the user.
- The exact storage method can be determined as the project develops and additional course concepts are introduced.
- My first goal is to make sure users can save and view their meal information correctly. More features can be added later as the project develops.

## V. Functionality

The Meal Planner application is planned to include the following functions:

- View a weekly meal plan.
- Add a meal to a selected day.
- Edit a previously entered meal.
- Remove a meal that is no longer needed.
- View saved meals in an organized format.
- Save meal-planning information so the user does not have to recreate the plan each time the application is opened.
- Additional features may be added later if they fit the course requirements and can be completed within the term.

## VI. Design and Wireframes

The application will use a simple layout with clear navigation between the main screens.

Initial wireframes include:

1. Home Screen
2. Weekly Meal Plan Screen
3. Add/Edit Meal Screen
4. Meal Details Screen

The wireframes show the planned placement of the major controls and information. The complete wireframes are included in the project outline.

## VII. Project Progress

The Meal Planner application is currently in the design and development phase. Since the initial project outline, I have continued developing the application's design and planning how information will be stored and managed.

### Current Progress

- Completed the initial project outline and application requirements.
- Created hand-drawn and digital wireframes for the application.
- Planned the weekly meal plan, meal entry, grocery list, and navigation features.
- Added database planning and researched the use of SQLite for local data storage.
- Updated the project Wiki with application design and database information.

### Next Steps

- Begin implementing the Meal Planner interface in Android.
- Develop the add and view meal functionality.
- Continue planning and developing the grocery list feature.
- Implement local data storage as appropriate.
- Test application functionality and correct identified issues.
- Continue pushing project updates to GitHub in preparation for the final submission.

## Current Project Progress

The Meal Planner application has entered the Android development stage. The initial user interface has been created in Android Studio and includes a weekly meal plan, an Add Meal button, and a Grocery List button.

Basic button functionality has been implemented and successfully tested using the Android emulator. The project documentation and wireframe have also been updated to reflect the current application design.

### Current Updates
- Created the initial Meal Planner interface in Android Studio.
- Added the weekly meal plan display.
- Added Add Meal and Grocery List buttons.
- Implemented basic button functionality.
- Successfully built and tested the application in the Android emulator.
- Updated the GitHub Wiki with current development progress.
- Pushed the current Android Studio project to GitHub.

### Future Updates
- Add functionality for creating and saving meals.
- Develop the grocery list feature.
- Implement local data storage.
- Continue improving the user interface.
- Test and finalize the application for the Module 8 submission.
